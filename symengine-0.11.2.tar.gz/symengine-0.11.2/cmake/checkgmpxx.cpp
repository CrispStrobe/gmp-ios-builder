#include <cstddef>
#include <iostream>
#include <gmpxx.h>

int main() {
    mpz_class m = 1;
    std::cout << m;
}
